<?php
/**
 * Created by PhpStorm.
 * User: willo
 * Date: 09/11/2018
 * Time: 19:35
 */

return array(
    'wsdl' => 'http://localhost:8080/TTTWebApplication/TTTWebService?WSDL',
    'username' => 'root',
    'cookieUserId' => 'userID',
    'cookieUsername' => 'username',
    'gameID' => 'gameID',

);